# Funciones en Azure para interactuar con ChatBot y Table Storage 

Fecha: 2020 Agosto

Por: Luz Eunice / Jos� Cruz

Funciones para interactuar con las tablas: 
- asistente : Informaci�n de los asistentes a las sesiones
- usuario : Colaboradores del �rea
- sesion : Sesiones planeadas y solicitantes a impartir las sesiones

Funciones generadas: 
- asistente
- solicitud
- lausuarios
- lasesion 
- asistente_cancelar


Requsitos en azure: 
- Function App
- Key vault 
- Tablas en un blob storage. 




